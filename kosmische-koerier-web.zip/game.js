"use strict";

const WIDTH = 900;
const HEIGHT = 620;
const FIELD_TOP = 90;
const FIELD_BOTTOM = HEIGHT - 24;
const CRYSTAL_GOAL = 8;
const CRYSTALS_ON_MAP = 6;
const PLAYER_SPEED = 245;
const DRONE_SPEED = 82;
const DASH_DURATION = 0.18;
const DASH_COOLDOWN = 1.1;
const DRONE_SPAWN_INTERVAL = 18;
const DRONE_WARNING_TIME = 3;
const SAVE_COUNT = 3;
const canvas = document.querySelector("#game");
const context = canvas.getContext("2d");
const pressedKeys = new Set();
const stars = Array.from({ length: 100 }, () => ({
  x: Math.random() * WIDTH,
  y: FIELD_TOP + Math.random() * (HEIGHT - FIELD_TOP),
  radius: Math.random() < 0.82 ? 1 : 2,
}));
const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
canvas.width = WIDTH * pixelRatio;
canvas.height = HEIGHT * pixelRatio;
context.scale(pixelRatio, pixelRatio);

let notice = "";
let saveSlots = Array(SAVE_COUNT).fill(null);

function distance(x1, y1, x2, y2) {
  return Math.hypot(x2 - x1, y2 - y1);
}

function isFinitePair(value) {
  return Array.isArray(value)
    && value.length === 2
    && value.every((coordinate) =>
      typeof coordinate === "number" && Number.isFinite(coordinate)
    );
}

class GameState {
  constructor() {
    this.reset();
  }

  reset() {
    this.level = 1;
    this.player = [WIDTH / 2, HEIGHT / 2];
    this.playerDirection = [1, 0];
    this.walls = this.levelWalls();
    this.crystals = [];
    this.drones = [];
    this.collected = 0;
    this.health = 3;
    this.shieldCharges = 0;
    this.shieldPickup = null;
    this.elapsed = 0;
    this.invulnerable = 0;
    this.dashCooldown = 0;
    this.dashTime = 0;
    this.screen = "playing";
    this.spawnCrystals(this.crystalSpawnCount);
    this.spawnDrone();
    this.spawnShieldPickup();
  }

  get crystalGoal() {
    return this.level * CRYSTAL_GOAL;
  }

  get crystalSpawnCount() {
    return Math.ceil(CRYSTALS_ON_MAP * 1.1 ** (this.level - 1));
  }

  get portal() {
    return [WIDTH - 76, FIELD_BOTTOM - 64];
  }

  levelWalls(level = this.level) {
    if (level % 4 !== 0) {
      return [];
    }
    return [
      [280, 180, 310, 350],
      [570, 340, 600, 510],
    ];
  }

  overlapsWall(x, y, radius, walls = this.walls) {
    return walls.some(([left, top, right, bottom]) =>
      left - radius <= x && x <= right + radius
      && top - radius <= y && y <= bottom + radius
    );
  }

  segmentHitsWall(start, end, radius) {
    for (const [wallLeft, wallTop, wallRight, wallBottom] of this.walls) {
      const left = wallLeft - radius - 1;
      const top = wallTop - radius - 1;
      const right = wallRight + radius + 1;
      const bottom = wallBottom + radius + 1;
      let minimumT = 0;
      let maximumT = 1;
      const axes = [
        [start[0], end[0] - start[0], left, right],
        [start[1], end[1] - start[1], top, bottom],
      ];
      for (const [origin, delta, minimum, maximum] of axes) {
        if (delta === 0) {
          if (origin < minimum || origin > maximum) {
            minimumT = 1;
            maximumT = 0;
            break;
          }
        } else {
          const first = (minimum - origin) / delta;
          const second = (maximum - origin) / delta;
          minimumT = Math.max(minimumT, Math.min(first, second));
          maximumT = Math.min(maximumT, Math.max(first, second));
          if (minimumT > maximumT) {
            break;
          }
        }
      }
      if (minimumT <= maximumT) {
        return true;
      }
    }
    return false;
  }

  droneTarget(index) {
    const count = this.drones.length;
    const cycle = Math.max(2.4, count * 1.25);
    const attackPhase = (this.elapsed - index * cycle / count) % cycle;
    const radius = attackPhase < 0.8 ? 22 : 42;
    const angle = 2 * Math.PI * index / count + this.elapsed * 0.3;
    return [
      Math.min(Math.max(this.player[0] + Math.cos(angle) * radius, 20), WIDTH - 20),
      Math.min(
        Math.max(this.player[1] + Math.sin(angle) * radius, FIELD_TOP - 10),
        FIELD_BOTTOM + 10,
      ),
    ];
  }

  droneWaypoint(drone, target = this.player) {
    if (!this.segmentHitsWall(drone, target, 14)) {
      return target;
    }
    const waypoints = [drone, target];
    const margin = 18;
    for (const [left, top, right, bottom] of this.walls) {
      waypoints.push(
        [left - margin, top - margin],
        [left - margin, bottom + margin],
        [right + margin, top - margin],
        [right + margin, bottom + margin],
      );
    }

    const costs = Array(waypoints.length).fill(Infinity);
    const previous = Array(waypoints.length).fill(null);
    const remaining = new Set(waypoints.map((_, index) => index));
    costs[0] = 0;
    while (remaining.size) {
      let current = null;
      for (const index of remaining) {
        if (current === null || costs[index] < costs[current]) {
          current = index;
        }
      }
      if (current === null || !Number.isFinite(costs[current])) {
        break;
      }
      remaining.delete(current);
      if (current === 1) {
        break;
      }
      for (const neighbor of remaining) {
        if (this.segmentHitsWall(waypoints[current], waypoints[neighbor], 14)) {
          continue;
        }
        const candidate = costs[current] + distance(
          waypoints[current][0], waypoints[current][1],
          waypoints[neighbor][0], waypoints[neighbor][1],
        );
        if (candidate < costs[neighbor]) {
          costs[neighbor] = candidate;
          previous[neighbor] = current;
        }
      }
    }
    if (previous[1] === null) {
      return target;
    }
    const route = [1];
    while (route[route.length - 1] !== 0) {
      route.push(previous[route[route.length - 1]]);
    }
    route.reverse();
    return waypoints[route[1]];
  }

  spawnCrystals(amount = 1) {
    for (let count = 0; count < amount; count += 1) {
      for (let attempt = 0; attempt < 100; attempt += 1) {
        const x = 48 + Math.floor(Math.random() * (WIDTH - 96));
        const y = FIELD_TOP + 28
          + Math.floor(Math.random() * (FIELD_BOTTOM - FIELD_TOP - 56));
        if (
          distance(x, y, ...this.player) > 105
          && distance(x, y, ...this.portal) > 90
          && !this.overlapsWall(x, y, 12)
        ) {
          this.crystals.push([x, y]);
          break;
        }
      }
    }
  }

  spawnShieldPickup() {
    this.shieldPickup = null;
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const x = 48 + Math.floor(Math.random() * (WIDTH - 96));
      const y = FIELD_TOP + 28
        + Math.floor(Math.random() * (FIELD_BOTTOM - FIELD_TOP - 56));
      if (
        distance(x, y, ...this.player) > 130
        && distance(x, y, ...this.portal) > 110
        && this.crystals.every((crystal) => distance(x, y, ...crystal) > 40)
        && !this.overlapsWall(x, y, 12)
      ) {
        this.shieldPickup = [x, y];
        return;
      }
    }
  }

  spawnDrone() {
    const side = ["left", "right", "top", "bottom"][
      Math.floor(Math.random() * 4)
    ];
    let position;
    if (side === "left") {
      position = [20, FIELD_TOP + Math.random() * (FIELD_BOTTOM - FIELD_TOP)];
    } else if (side === "right") {
      position = [
        WIDTH - 20,
        FIELD_TOP + Math.random() * (FIELD_BOTTOM - FIELD_TOP),
      ];
    } else if (side === "top") {
      position = [20 + Math.random() * (WIDTH - 40), FIELD_TOP - 10];
    } else {
      position = [20 + Math.random() * (WIDTH - 40), FIELD_BOTTOM + 10];
    }
    this.drones.push(position);
  }

  nextLevel() {
    this.level += 1;
    this.player = [WIDTH / 2, HEIGHT / 2];
    this.playerDirection = [1, 0];
    this.walls = this.levelWalls();
    this.crystals = [];
    this.drones = [];
    this.collected = 0;
    this.elapsed = 0;
    this.invulnerable = 0;
    this.dashCooldown = 0;
    this.dashTime = 0;
    this.shieldCharges = 0;
    this.screen = "playing";
    this.spawnCrystals(this.crystalSpawnCount);
    this.spawnDrone();
    this.spawnShieldPickup();
  }

  step(dt, directions, dash) {
    if (this.screen !== "playing") {
      return;
    }
    dt = Math.min(dt, 0.05);
    this.elapsed += dt;
    this.invulnerable = Math.max(0, this.invulnerable - dt);
    this.dashCooldown = Math.max(0, this.dashCooldown - dt);
    this.dashTime = Math.max(0, this.dashTime - dt);
    if (dash && this.dashCooldown === 0) {
      this.dashTime = DASH_DURATION;
      this.dashCooldown = DASH_COOLDOWN;
    }

    const dx = Number(directions.has("right")) - Number(directions.has("left"));
    const dy = Number(directions.has("down")) - Number(directions.has("up"));
    if (dx || dy) {
      const magnitude = Math.hypot(dx, dy);
      this.playerDirection = [dx / magnitude, dy / magnitude];
      const speed = PLAYER_SPEED * (this.dashTime ? 2.35 : 1);
      const moveX = dx / magnitude * speed * dt;
      const moveY = dy / magnitude * speed * dt;
      if (!this.overlapsWall(this.player[0] + moveX, this.player[1], 20)) {
        this.player[0] += moveX;
      }
      if (!this.overlapsWall(this.player[0], this.player[1] + moveY, 20)) {
        this.player[1] += moveY;
      }
    }
    this.player[0] = Math.min(Math.max(22, this.player[0]), WIDTH - 22);
    this.player[1] = Math.min(
      Math.max(FIELD_TOP + 12, this.player[1]),
      FIELD_BOTTOM - 12,
    );

    for (const crystal of [...this.crystals]) {
      if (distance(...this.player, ...crystal) < 27) {
        this.crystals.splice(this.crystals.indexOf(crystal), 1);
        this.collected += 1;
        this.spawnCrystals();
      }
    }
    if (
      this.shieldPickup
      && this.shieldCharges === 0
      && distance(...this.player, ...this.shieldPickup) < 27
    ) {
      this.shieldCharges = 1;
      this.shieldPickup = null;
    }

    for (let index = 0; index < this.drones.length; index += 1) {
      const drone = this.drones[index];
      let target = this.droneTarget(index);
      if (this.overlapsWall(...target, 14)) {
        target = this.player;
      }
      const [waypointX, waypointY] = this.droneWaypoint(drone, target);
      let steerX = waypointX - drone[0];
      let steerY = waypointY - drone[1];
      for (let otherIndex = 0; otherIndex < this.drones.length; otherIndex += 1) {
        if (otherIndex === index) {
          continue;
        }
        const other = this.drones[otherIndex];
        let awayX = drone[0] - other[0];
        let awayY = drone[1] - other[1];
        const separation = Math.hypot(awayX, awayY);
        if (separation >= 36) {
          continue;
        }
        if (separation === 0) {
          const angle = 2 * Math.PI * index / this.drones.length;
          awayX = Math.cos(angle);
          awayY = Math.sin(angle);
        } else {
          awayX /= separation;
          awayY /= separation;
        }
        const strength = (36 - separation) * 3;
        steerX += awayX * strength;
        steerY += awayY * strength;
      }
      const steeringLength = Math.max(Math.hypot(steerX, steerY), 1);
      const movement = Math.min(DRONE_SPEED * dt, steeringLength);
      const moveX = steerX / steeringLength * movement;
      const moveY = steerY / steeringLength * movement;
      if (!this.overlapsWall(drone[0] + moveX, drone[1], 14)) {
        drone[0] += moveX;
      }
      if (!this.overlapsWall(drone[0], drone[1] + moveY, 14)) {
        drone[1] += moveY;
      }
      const playerSeparation = Math.max(
        distance(...this.player, ...drone),
        1,
      );
      if (playerSeparation < 26 && this.invulnerable === 0) {
        if (this.shieldCharges) {
          this.shieldCharges = 0;
          this.invulnerable = 0.8;
        } else {
          this.health -= 1;
          this.invulnerable = 1.2;
        }
        const pushX = this.player[0]
          + (this.player[0] - drone[0]) / playerSeparation * 38;
        const pushY = this.player[1]
          + (this.player[1] - drone[1]) / playerSeparation * 38;
        if (!this.overlapsWall(pushX, this.player[1], 20)) {
          this.player[0] = Math.min(Math.max(30, pushX), WIDTH - 30);
        }
        if (!this.overlapsWall(this.player[0], pushY, 20)) {
          this.player[1] = Math.min(
            Math.max(FIELD_TOP + 20, pushY),
            FIELD_BOTTOM - 20,
          );
        }
        if (this.health <= 0) {
          this.screen = "over";
        }
        break;
      }
    }
    if (this.elapsed >= DRONE_SPAWN_INTERVAL && this.drones.length < 5) {
      this.elapsed = 0;
      this.spawnDrone();
    }
    if (
      this.collected >= this.crystalGoal
      && distance(...this.player, ...this.portal) < 42
    ) {
      this.screen = "won";
    }
  }

  toJSON() {
    return {
      level: this.level,
      player: this.player,
      playerDirection: this.playerDirection,
      crystals: this.crystals,
      drones: this.drones,
      collected: this.collected,
      health: this.health,
      shieldCharges: this.shieldCharges,
      shieldPickup: this.shieldPickup,
      elapsed: this.elapsed,
      invulnerable: this.invulnerable,
      dashCooldown: this.dashCooldown,
      dashTime: this.dashTime,
    };
  }

  load(data) {
    if (!data || typeof data !== "object" || Array.isArray(data)) {
      throw new Error("Ongeldige spelgegevens.");
    }
    if (!Number.isInteger(data.level) || data.level < 1) {
      throw new Error("Het opgeslagen level is ongeldig.");
    }
    if (!Number.isInteger(data.collected) || data.collected < 0) {
      throw new Error("De opgeslagen kristaltelling is ongeldig.");
    }
    if (!Number.isInteger(data.health) || data.health < 1 || data.health > 3) {
      throw new Error("Het opgeslagen aantal levens is ongeldig.");
    }
    const shieldCharges = data.shieldCharges ?? 0;
    if (!Number.isInteger(shieldCharges) || shieldCharges < 0 || shieldCharges > 1) {
      throw new Error("De opgeslagen schildlading is ongeldig.");
    }
    const walls = this.levelWalls(data.level);
    const validatePosition = (value, label, radius = 0) => {
      if (!isFinitePair(value)) {
        throw new Error(`Ongeldige positie voor ${label}.`);
      }
      const point = value.slice();
      if (this.overlapsWall(point[0], point[1], radius, walls)) {
        throw new Error(`De opgeslagen positie van ${label} ligt in een muur.`);
      }
      return point;
    };
    const player = validatePosition(data.player, "speler", 20);
    const direction = validatePosition(data.playerDirection, "richting");
    const directionLength = Math.hypot(...direction);
    if (directionLength === 0) {
      throw new Error("De opgeslagen richting is ongeldig.");
    }
    const playerDirection = direction.map((value) => value / directionLength);
    if (
      player[0] < 22 || player[0] > WIDTH - 22
      || player[1] < FIELD_TOP + 12 || player[1] > FIELD_BOTTOM - 12
    ) {
      throw new Error("De opgeslagen speler staat buiten het speelveld.");
    }
    if (!Array.isArray(data.crystals) || data.crystals.length > 100) {
      throw new Error("De opgeslagen kristallen zijn ongeldig.");
    }
    if (!Array.isArray(data.drones) || data.drones.length > 5) {
      throw new Error("De opgeslagen drones zijn ongeldig.");
    }
    const crystals = data.crystals.map((point) =>
      validatePosition(point, "kristal", 12)
    );
    const drones = data.drones.map((point) =>
      validatePosition(point, "drone", 14)
    );
    const shieldPickup = data.shieldPickup == null
      ? null
      : validatePosition(data.shieldPickup, "schild", 12);
    for (const point of [...crystals, ...drones, ...(shieldPickup ? [shieldPickup] : [])]) {
      if (point[0] < 0 || point[0] > WIDTH || point[1] < 0 || point[1] > HEIGHT) {
        throw new Error("Een opgeslagen object staat buiten het speelveld.");
      }
    }
    const timer = (name, maximum = Infinity) => {
      const value = data[name];
      if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > maximum) {
        throw new Error(`De opgeslagen tijd (${name}) is ongeldig.`);
      }
      return value;
    };
    const elapsed = timer("elapsed");
    const invulnerable = timer("invulnerable", 1.2);
    const dashCooldown = timer("dashCooldown", DASH_COOLDOWN);
    const dashTime = timer("dashTime", DASH_DURATION);

    Object.assign(this, {
      level: data.level,
      walls,
      player,
      playerDirection,
      crystals,
      drones,
      collected: data.collected,
      health: data.health,
      shieldCharges,
      shieldPickup,
      elapsed,
      invulnerable,
      dashCooldown,
      dashTime,
      screen: "playing",
    });
  }
}

let state = new GameState();
state.screen = "menu";

function readSaveSlots() {
  for (let index = 0; index < SAVE_COUNT; index += 1) {
    try {
      const raw = localStorage.getItem(`kosmische-koerier-slot-${index + 1}`);
      saveSlots[index] = raw ? JSON.parse(raw) : null;
      if (
        saveSlots[index] !== null
        && (typeof saveSlots[index] !== "object" || Array.isArray(saveSlots[index]))
      ) {
        throw new Error("Ongeldige opslag.");
      }
    } catch (error) {
      saveSlots[index] = null;
      notice = `Slot ${index + 1} kon niet worden gelezen: ${error.message}`;
    }
  }
}

function startGame() {
  state.reset();
  notice = "";
  pressedKeys.clear();
}

function loadSlot(index) {
  const data = saveSlots[index];
  if (!data) {
    notice = `Slot ${index + 1} is leeg.`;
    return;
  }
  try {
    state.load(data);
    notice = "";
    pressedKeys.clear();
  } catch (error) {
    notice = `Slot ${index + 1} kon niet worden geladen: ${error.message}`;
  }
}

function saveSlot(index) {
  try {
    const snapshot = state.toJSON();
    localStorage.setItem(
      `kosmische-koerier-slot-${index + 1}`,
      JSON.stringify(snapshot),
    );
    saveSlots[index] = snapshot;
    notice = `Spel opgeslagen in slot ${index + 1}.`;
    state.screen = "paused";
  } catch (error) {
    notice = `Opslaan is mislukt: ${error.message}`;
    state.screen = "paused";
  }
}

function onKeyDown(event) {
  const key = event.key.toLowerCase();
  if (["arrowleft", "arrowright", "arrowup", "arrowdown", " "].includes(key)) {
    event.preventDefault();
  }
  if (state.screen === "menu") {
    if (["enter", "n"].includes(key)) {
      startGame();
    } else if (["1", "2", "3"].includes(key)) {
      loadSlot(Number(key) - 1);
    }
    return;
  }
  if (state.screen === "saving") {
    if (["1", "2", "3"].includes(key)) {
      saveSlot(Number(key) - 1);
    } else if (key === "escape" || key === "p") {
      state.screen = "paused";
    }
    return;
  }
  if (state.screen === "paused") {
    if (key === "p" || key === "escape") {
      state.screen = "playing";
    } else if (key === "s") {
      state.screen = "saving";
    }
    return;
  }
  if (state.screen === "over" || state.screen === "won") {
    if (key === "enter") {
      if (state.screen === "over") {
        startGame();
      } else {
        state.nextLevel();
      }
    }
    return;
  }
  const directionKeys = {
    arrowleft: "left",
    a: "left",
    arrowright: "right",
    d: "right",
    arrowup: "up",
    w: "up",
    arrowdown: "down",
    s: "down",
  };
  if (directionKeys[key]) {
    pressedKeys.add(directionKeys[key]);
  } else if (key === " ") {
    pressedKeys.add("dash");
  } else if (key === "p" || key === "escape") {
    state.screen = "paused";
  }
}

function onKeyUp(event) {
  const key = event.key.toLowerCase();
  const directionKeys = {
    arrowleft: "left",
    a: "left",
    arrowright: "right",
    d: "right",
    arrowup: "up",
    w: "up",
    arrowdown: "down",
    s: "down",
    " ": "dash",
  };
  if (directionKeys[key]) {
    pressedKeys.delete(directionKeys[key]);
  }
}

function canvasPoint(event) {
  const bounds = canvas.getBoundingClientRect();
  return [
    (event.clientX - bounds.left) * WIDTH / bounds.width,
    (event.clientY - bounds.top) * HEIGHT / bounds.height,
  ];
}

function onCanvasClick(event) {
  const [x, y] = canvasPoint(event);
  if (state.screen === "menu") {
    if (x >= 220 && x <= 680 && y >= 390 && y <= 430) {
      startGame();
      return;
    }
    for (let index = 0; index < SAVE_COUNT; index += 1) {
      const top = 440 + index * 46;
      if (x >= 220 && x <= 680 && y >= top && y <= top + 42) {
        loadSlot(index);
        return;
      }
    }
  } else if (state.screen === "saving") {
    for (let index = 0; index < SAVE_COUNT; index += 1) {
      const top = 365 + index * 47;
      if (x >= 220 && x <= 680 && y >= top && y <= top + 40) {
        saveSlot(index);
        return;
      }
    }
    if (x >= 220 && x <= 680 && y >= 510 && y <= 550) {
      state.screen = "paused";
    }
  }
}

function drawText(text, x, y, size, color, weight = "normal", align = "center") {
  context.fillStyle = color;
  context.font = `${weight} ${size}px "Segoe UI", Arial, sans-serif`;
  context.textAlign = align;
  context.textBaseline = "middle";
  context.fillText(text, x, y);
}

function roundedRect(x, y, width, height, radius, fill, stroke) {
  context.beginPath();
  context.roundRect(x, y, width, height, radius);
  context.fillStyle = fill;
  context.fill();
  if (stroke) {
    context.strokeStyle = stroke;
    context.lineWidth = 1;
    context.stroke();
  }
}

function drawStars() {
  context.fillStyle = "#080d1b";
  context.fillRect(0, 0, WIDTH, HEIGHT);
  for (const star of stars) {
    context.globalAlpha = star.radius === 1 ? 0.55 : 0.85;
    context.fillStyle = "#8293bd";
    context.beginPath();
    context.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
    context.fill();
  }
  context.globalAlpha = 1;
}

function drawButton(y, label, active = false) {
  roundedRect(
    220, y, 460, 42, 8,
    active ? "#173c48" : "#151f36",
    active ? "#75e6d1" : "#39445f",
  );
  drawText(label, WIDTH / 2, y + 21, 14, active ? "#75e6d1" : "#edf0fa", "700");
}

function drawMenu() {
  drawStars();
  drawText("KOSMISCHE", WIDTH / 2, 118, 22, "#75e6d1", "700");
  drawText("KOERIER", WIDTH / 2, 177, 48, "#f3f5ff", "700");
  drawText("Een klein avontuur tussen de sterren", WIDTH / 2, 226, 15, "#aab5d0");
  drawText("Verzamel kristallen en bereik de PORTAAL", WIDTH / 2, 270, 17, "#edf0fa", "700");
  drawText("WASD / pijltjes bewegen  •  SPATIE dash  •  P pauze", WIDTH / 2, 310, 13, "#aab5d0");
  drawText("Blauw schildkristal vangt één drone-aanval op", WIDTH / 2, 337, 12, "#63c7ff");
  drawButton(390, "NIEUW SPEL  (ENTER / N)", true);
  for (let index = 0; index < SAVE_COUNT; index += 1) {
    const slot = saveSlots[index];
    const label = slot
      ? `LAAD SLOT ${index + 1}  •  LEVEL ${slot.level ?? "?"}  •  ${slot.collected ?? "?"} KRISTALLEN`
      : `LAAD SLOT ${index + 1}  •  LEEG`;
    drawButton(440 + index * 46, label);
  }
  drawText("Klik op een slot of druk op 1, 2 of 3 om te laden.", WIDTH / 2, 590, 11, "#73809d");
  if (notice) {
    drawText(notice, WIDTH / 2, 610, 10, "#ffb5bd");
  }
}

function drawPortal() {
  const [x, y] = state.portal;
  const active = state.collected >= state.crystalGoal;
  context.save();
  context.shadowBlur = active ? 16 : 0;
  context.shadowColor = "#75e6d1";
  context.strokeStyle = active ? "#75e6d1" : "#39445f";
  context.lineWidth = 3;
  context.beginPath();
  context.arc(x, y, 26 + Math.sin(state.elapsed * 3) * 2, 0, Math.PI * 2);
  context.stroke();
  context.lineWidth = 1;
  context.beginPath();
  context.arc(x, y, 17, 0, Math.PI * 2);
  context.stroke();
  context.restore();
  drawText("PORTAAL", x, y + 39, 9, active ? "#75e6d1" : "#68728b", "700");
}

function drawCrystal(x, y) {
  context.beginPath();
  context.moveTo(x, y - 10);
  context.lineTo(x + 8, y);
  context.lineTo(x, y + 10);
  context.lineTo(x - 8, y);
  context.closePath();
  context.fillStyle = "#f2d47b";
  context.strokeStyle = "#fff0bd";
  context.fill();
  context.stroke();
  context.fillStyle = "#fff9dd";
  context.beginPath();
  context.arc(x, y, 2, 0, Math.PI * 2);
  context.fill();
}

function drawShieldPickup(x, y) {
  context.strokeStyle = "#63c7ff";
  context.lineWidth = 2;
  context.beginPath();
  context.arc(x, y, 15 + Math.sin(state.elapsed * 4) * 2, 0, Math.PI * 2);
  context.stroke();
  context.beginPath();
  context.moveTo(x, y - 10);
  context.lineTo(x + 8, y - 4);
  context.lineTo(x + 6, y + 6);
  context.lineTo(x, y + 11);
  context.lineTo(x - 6, y + 6);
  context.lineTo(x - 8, y - 4);
  context.closePath();
  context.fillStyle = "#3ba8e8";
  context.fill();
  context.strokeStyle = "#c4efff";
  context.stroke();
}

function drawDrone(x, y) {
  context.fillStyle = "#d94f73";
  context.strokeStyle = "#ff96a9";
  context.lineWidth = 2;
  context.beginPath();
  context.arc(x, y, 14, 0, Math.PI * 2);
  context.fill();
  context.stroke();
  context.fillStyle = "#fff0f2";
  context.beginPath();
  context.arc(x - 3, y - 2, 2, 0, Math.PI * 2);
  context.arc(x + 4, y - 2, 2, 0, Math.PI * 2);
  context.fill();
}

function drawPlayer() {
  const [x, y] = state.player;
  if (state.invulnerable > 0 && Math.floor(state.invulnerable * 12) % 2) {
    return;
  }
  context.fillStyle = "#1e4656";
  context.strokeStyle = "#75e6d1";
  context.lineWidth = 2;
  context.beginPath();
  context.arc(x, y, 20, 0, Math.PI * 2);
  context.fill();
  context.stroke();
  if (state.shieldCharges) {
    context.strokeStyle = "#63c7ff";
    context.beginPath();
    context.arc(x, y, 25, 0, Math.PI * 2);
    context.stroke();
  }
  context.save();
  context.translate(x, y);
  context.rotate(Math.atan2(state.playerDirection[1], state.playerDirection[0]));
  if (state.dashTime) {
    context.strokeStyle = "#75e6d1";
    context.lineWidth = 3;
    context.beginPath();
    context.moveTo(-20, 0);
    context.lineTo(-38, 0);
    context.stroke();
  }
  context.beginPath();
  context.moveTo(15, 0);
  context.lineTo(-8, -11);
  context.lineTo(-4, 0);
  context.lineTo(-8, 11);
  context.closePath();
  context.fillStyle = "#f3f5ff";
  context.strokeStyle = "#b6fff1";
  context.fill();
  context.stroke();
  context.restore();
}

function drawArena() {
  drawStars();
  context.fillStyle = "#10182b";
  context.fillRect(0, 0, WIDTH, FIELD_TOP);
  context.strokeStyle = "#273553";
  context.lineWidth = 2;
  context.beginPath();
  context.moveTo(0, FIELD_TOP);
  context.lineTo(WIDTH, FIELD_TOP);
  context.stroke();

  drawText("KOSMISCHE KOERIER", 25, 30, 14, "#75e6d1", "700", "left");
  drawText(
    `KRISTALLEN   ${Math.min(state.collected, state.crystalGoal)} / ${state.crystalGoal}`,
    WIDTH - 25, 30, 14, "#f2d47b", "700", "right",
  );
  drawText(`LEVEL ${state.level}`, WIDTH / 2, 62, 10, "#aab5d0", "700");
  drawText("LEVENS", 25, 62, 10, "#aab5d0", "700", "left");
  for (let index = 0; index < 3; index += 1) {
    const x = 89 + index * 22;
    context.beginPath();
    context.moveTo(x, 54);
    context.lineTo(x - 8, 63);
    context.lineTo(x, 72);
    context.lineTo(x + 8, 63);
    context.closePath();
    context.fillStyle = index < state.health ? "#ff718f" : "#30374b";
    context.fill();
  }
  drawText("DASH", 165, 63, 9, "#aab5d0", "700");
  const dashProgress = 1 - Math.min(state.dashCooldown / DASH_COOLDOWN, 1);
  roundedRect(190, 56, 80, 13, 3, "#202a40", "#526481");
  if (dashProgress > 0) {
    roundedRect(
      191, 57, 78 * dashProgress, 11, 2,
      dashProgress >= 1 ? "#75e6d1" : "#687da8",
    );
  }
  const shieldColor = state.shieldCharges ? "#75e6d1" : "#39445f";
  context.fillStyle = shieldColor;
  context.strokeStyle = "#aab5d0";
  context.beginPath();
  context.moveTo(288, 54);
  context.lineTo(296, 57);
  context.lineTo(295, 66);
  context.lineTo(288, 71);
  context.lineTo(281, 66);
  context.lineTo(280, 57);
  context.closePath();
  context.fill();
  context.stroke();
  drawText("SCHILD", 304, 63, 9, shieldColor, "700", "left");

  for (const [left, top, right, bottom] of state.walls) {
    roundedRect(left, top, right - left, bottom - top, 4, "#293654", "#526481");
  }
  drawPortal();
  for (const [x, y] of state.crystals) {
    drawCrystal(x, y);
  }
  if (state.shieldPickup) {
    drawShieldPickup(...state.shieldPickup);
  }
  for (const [x, y] of state.drones) {
    drawDrone(x, y);
  }
  drawPlayer();

  const droneWarning = state.elapsed >= DRONE_SPAWN_INTERVAL - DRONE_WARNING_TIME
    && state.elapsed < DRONE_SPAWN_INTERVAL
    && state.drones.length < 5;
  if (droneWarning) {
    const secondsLeft = Math.ceil(DRONE_SPAWN_INTERVAL - state.elapsed);
    drawText(
      `DRONE NADERT OVER ${secondsLeft} SECONDEN!`,
      WIDTH / 2, FIELD_TOP + 17, 11, "#ff718f", "700",
    );
  }
  if (state.collected >= state.crystalGoal) {
    drawText(
      "PORTAAL GEACTIVEERD - bereik de cirkel!",
      WIDTH / 2, FIELD_TOP + (droneWarning ? 38 : 17), 11, "#75e6d1", "700",
    );
  }
}

function drawOverlay(title, subtitle) {
  context.fillStyle = "#050914aa";
  context.fillRect(0, 0, WIDTH, HEIGHT);
  drawText(title, WIDTH / 2, HEIGHT / 2 - 25, 34, "#f3f5ff", "700");
  const lines = subtitle.split("\n");
  lines.forEach((line, index) =>
    drawText(line, WIDTH / 2, HEIGHT / 2 + 20 + index * 24, 14, "#aab5d0")
  );
}

function drawSavingMenu() {
  drawOverlay(
    "SPEL OPSLAAN",
    "Kies een slot om op te slaan (bestaande gegevens worden overschreven).",
  );
  for (let index = 0; index < SAVE_COUNT; index += 1) {
    const slot = saveSlots[index];
    const label = slot
      ? `SLOT ${index + 1}  •  HUIDIG LEVEL ${slot.level ?? "?"}`
      : `SLOT ${index + 1}  •  LEEG`;
    drawButton(365 + index * 47, label);
  }
  drawText("Druk op 1, 2 of 3  •  ESC om terug te gaan", WIDTH / 2, 530, 11, "#aab5d0");
}

function draw() {
  if (state.screen === "menu") {
    drawMenu();
    return;
  }
  drawArena();
  if (state.screen === "saving") {
    drawSavingMenu();
  } else if (state.screen === "paused") {
    drawOverlay(
      "PAUZE",
      `${notice ? `${notice}\n` : ""}S • opslaan   P / ESC • verder spelen`,
    );
  } else if (state.screen === "won") {
    drawOverlay(
      `LEVEL ${state.level} VOLTOOID!`,
      `Druk op ENTER voor level ${state.level + 1}`,
    );
  } else if (state.screen === "over") {
    drawOverlay("GAME OVER", "Druk op ENTER om opnieuw te proberen");
  }
}

function frame(timestamp) {
  const dt = frame.lastTime === undefined
    ? 0
    : Math.min((timestamp - frame.lastTime) / 1000, 0.05);
  frame.lastTime = timestamp;
  state.step(dt, pressedKeys, pressedKeys.has("dash"));
  draw();
  requestAnimationFrame(frame);
}

window.addEventListener("keydown", onKeyDown);
window.addEventListener("keyup", onKeyUp);
window.addEventListener("blur", () => pressedKeys.clear());
canvas.addEventListener("click", onCanvasClick);
document.querySelectorAll(".touch-controls [data-key]").forEach((button) => {
  const key = button.dataset.key;
  button.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    pressedKeys.add(key);
    button.setPointerCapture(event.pointerId);
  });
  const release = (event) => {
    event.preventDefault();
    pressedKeys.delete(key);
  };
  button.addEventListener("pointerup", release);
  button.addEventListener("pointercancel", release);
  button.addEventListener("lostpointercapture", release);
});
readSaveSlots();
requestAnimationFrame(frame);

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch((error) => {
      console.error("De offlinecache kon niet worden gestart.", error);
    });
  });
}
